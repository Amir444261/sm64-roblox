# Shared - Cloud Assets

This folder contains cloud asset mapping for custom Roblox assets that I use in funny 64-bit platformer. The content linked in here does not source from any assets or content from Nintendo. Voice acting was done by me, and animation work was done by Stalkalek. I also borrowed some stock sounds from Roblox.