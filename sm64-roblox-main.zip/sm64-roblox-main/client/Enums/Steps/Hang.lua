--!strict

return {
	NONE = 0,
	HIT_CEIL_OR_OOB = 1,
	LEFT_CEIL = 2,
}
