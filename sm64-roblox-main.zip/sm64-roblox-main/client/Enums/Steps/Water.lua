--!strict

return {
	NONE = 0,
	HIT_FLOOR = 1,
	HIT_CEILING = 2,
	CANCELLED = 3,
	HIT_WALL = 4,
}
