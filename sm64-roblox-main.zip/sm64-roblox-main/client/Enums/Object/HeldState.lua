--!strict

return {
	FREE = 0,
	HELD = 1,
	THROWN = 2,
	DROPPED = 3,
}
