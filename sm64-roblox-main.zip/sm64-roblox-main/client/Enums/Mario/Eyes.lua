--!strict

return {
	BLINK = 0,
	OPEN = 1,

	HALF_CLOSED = 2,
	CLOSED = 3,

	DEAD = 4,
}
