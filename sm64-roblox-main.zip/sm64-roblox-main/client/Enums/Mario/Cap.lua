--!strict

return {
	DEFAULT_CAP_ON = 0,
	DEFAULT_CAP_OFF = 1,

	WING_CAP_ON = 2,
	WING_CAP_OFF = 3,
}
