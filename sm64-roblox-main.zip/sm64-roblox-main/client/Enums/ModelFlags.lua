--!strict

return {
	METAL = 0x1,
	INVISIBLE = 0x2,
	NOISE_ALPHA = 0x4,
}
