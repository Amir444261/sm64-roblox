--!strict

return {
	FISTS = 0,
	OPEN = 1,
	PEACE_SIGN = 2,
	HOLDING_CAP = 3,
	HOLDING_WING_CAP = 4,
	RIGHT_OPEN = 5,
}
